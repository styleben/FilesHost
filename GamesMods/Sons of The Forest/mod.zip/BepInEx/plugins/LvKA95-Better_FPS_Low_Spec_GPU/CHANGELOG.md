- Added a FPS (Frame Per Second) Counter (Current, Average, Minimum) You can also choose the position on the screen to show the current FPS
- Added 1 Toggle to remove (Render) to tufts of grass in the terrain
- Changed and cleaner UI interface
## 13 October 2023 v0.1.2

- Added button to apply all settings
- Fixed bug K hotkey usually not working
- Fixed bugs where lighter/flashlight shadows didn't turn off
- Optimized Code
- Changed and cleaner UI interface
## 17 April 2023 v0.1.1

- Added Hotkey K (Key Configurable in mod manager) to remove shadows without opening the menu
- Added 1 Toggle to remove Shadow from LocalPlayerPlasmaLight, FireLight, SpotLight
## 11 April 2023 v0.0.3

- Added Language Choices (ENG, ITA)
- Added 9 toggle to remove (Render) from Texture 2D Far Distance, Ocean Waves, Some Distant Elements, Distant Trees, Small Bush, Moss, Wood Chips Particle, Beach Waves, Small Trees
- Added slider to change terrain geometry details
- Added slider to change camera view distance
- Added toggle to remove shadows from sunlight/moonlight
## 10 April 2023 v0.0.1