Simple plugin to disable graphical rendering of in-game elements (example trees) or Change the rendering distance of the camera in the game scene, allowing an excellent performance boost
Press F9 to enable the menu (Only activates after loading a save)
You can change the key via config files on thunderstore mod manager!

Requires [BepInEx IL2CPP](https://thunderstore.io/c/sons-of-the-forest/p/BepInEx/BepInExPack_IL2CPP/)